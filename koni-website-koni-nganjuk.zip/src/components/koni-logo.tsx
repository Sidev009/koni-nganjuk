import { Flame } from "lucide-react";

export function KoniLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex min-w-0 items-center gap-3">
      <span className="grid size-11 shrink-0 place-items-center rounded-full border-2 border-accent bg-primary text-accent shadow-sm">
        <Flame className="size-6 fill-current" aria-hidden="true" />
      </span>
      {!compact && (
        <span className="min-w-0 leading-tight">
          <strong className="block truncate font-display text-base font-extrabold text-primary">KONI NGANJUK</strong>
          <span className="block truncate text-[11px] font-semibold uppercase text-muted-foreground">Komite Olahraga Nasional Indonesia</span>
        </span>
      )}
    </div>
  );
}